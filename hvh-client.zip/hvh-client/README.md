# HvH Client (Fabric 1.21.11)

## البناء
1. ثبّت JDK 21.
2. افتح https://fabricmc.net/develop وتأكد من قيم `yarn_mappings` و `fabric_version` بملف gradle.properties.
3. `./gradlew build` (إذا ما عندك gradlew: `gradle wrapper --gradle-version 9.2.0` أولاً).
4. الجار بـ `build/libs/hvh-client-1.0.0.jar` حطه بـ mods مع Fabric API.

## الاستخدام
- **Right Shift** يفتح القائمة (غيره من `HvhClient.GUI_KEY`).
- كليك يسار = تشغيل/إيقاف، يمين = الإعدادات، وسط = تغيير زر المود.
- الكونفك: `.minecraft/config/hvhclient/hvh.cfg` (مفاتيح انجليزية، ينحفظ لما تسكر القائمة).

## إضافة مود جديد
كلاس يمدد `Module`، تضيف settings بـ `add(...)`، وتسجله بـ `ModuleManager`. اسم المود لازم يطابق اسمه بملف الكونفك.

Sprint / Fullbright / FpsBoost مأخوذة من ABN (Aboudi_DEV, MIT).
