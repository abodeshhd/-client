package hvh.client;

import hvh.client.gui.ClickGui;
import hvh.client.module.Module;
import hvh.client.module.ModuleManager;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public class HvhClient implements ClientModInitializer {
    public static ModuleManager modules;
    /** زر فتح القائمة، غيره لأي زر تريده */
    public static final int GUI_KEY = GLFW.GLFW_KEY_RIGHT_SHIFT;
    private boolean guiKeyDown;

    @Override
    public void onInitializeClient() {
        modules = new ModuleManager();
        ConfigManager.init();

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            if (mc.player == null) return;
            if (mc.currentScreen == null) {
                long win = mc.getWindow().getHandle();
                boolean g = GLFW.glfwGetKey(win, GUI_KEY) == GLFW.GLFW_PRESS;
                if (g && !guiKeyDown) mc.setScreen(new ClickGui());
                guiKeyDown = g;

                for (Module m : modules.modules) {
                    if (m.key <= 0) continue;
                    boolean d = GLFW.glfwGetKey(win, m.key) == GLFW.GLFW_PRESS;
                    if (d && !m.keyDown) {
                        m.toggle();
                        mc.player.sendMessage(Text.literal("[HvH] " + m.name + (m.enabled ? " ON" : " OFF")), true);
                    }
                    m.keyDown = d;
                }
            }
            modules.tick();
        });
    }
}
