package hvh.client.setting;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;

import java.util.*;

public abstract class Setting {
    public final String name; // الاسم الانجليزي (هو مفتاح الكونفك)
    public final String ar;   // الاسم العربي (للعرض بالقائمة)

    protected Setting(String name, String ar) {
        this.name = name;
        this.ar = ar;
    }

    public abstract JsonElement toJson();
    public abstract void fromJson(JsonElement e);

    public static class Bool extends Setting {
        public boolean value;
        public Bool(String name, String ar, boolean def) { super(name, ar); value = def; }
        public JsonElement toJson() { return new JsonPrimitive(value); }
        public void fromJson(JsonElement e) {
            if (e.isJsonPrimitive() && e.getAsJsonPrimitive().isBoolean()) value = e.getAsBoolean();
        }
    }

    public static class Num extends Setting {
        public double value;
        public final double min, max;
        public Num(String name, String ar, double def, double min, double max) {
            super(name, ar); this.min = min; this.max = max; set(def);
        }
        public void set(double v) { value = Math.max(min, Math.min(max, Math.round(v * 100.0) / 100.0)); }
        public JsonElement toJson() { return new JsonPrimitive(value); }
        public void fromJson(JsonElement e) {
            if (e.isJsonPrimitive() && e.getAsJsonPrimitive().isNumber()) set(e.getAsDouble());
        }
    }

    public static class Mode extends Setting {
        public final String[] options, optionsAr;
        public int index;
        public Mode(String name, String ar, String[] options, String[] optionsAr, int def) {
            super(name, ar); this.options = options; this.optionsAr = optionsAr; this.index = def;
        }
        public String get() { return options[index]; }
        public String getAr() { return optionsAr[index]; }
        public void cycle() { index = (index + 1) % options.length; }
        public JsonElement toJson() { return new JsonPrimitive(options[index]); }
        public void fromJson(JsonElement e) {
            if (!e.isJsonPrimitive()) return;
            String s = e.getAsString();
            for (int i = 0; i < options.length; i++) if (s.equals(options[i])) index = i;
        }
    }

    public static class Multi extends Setting {
        public final String[] options, optionsAr;
        public final boolean[] on;
        public Multi(String name, String ar, String[] options, String[] optionsAr, boolean[] def) {
            super(name, ar); this.options = options; this.optionsAr = optionsAr; this.on = def.clone();
        }
        public boolean has(int i) { return on[i]; }
        public JsonElement toJson() {
            StringJoiner j = new StringJoiner(",");
            for (int i = 0; i < options.length; i++) if (on[i]) j.add(options[i]);
            return new JsonPrimitive(j.toString());
        }
        public void fromJson(JsonElement e) {
            if (!e.isJsonPrimitive()) return;
            Set<String> set = new HashSet<>();
            for (String p : e.getAsString().split(",")) set.add(p.trim());
            for (int i = 0; i < options.length; i++) on[i] = set.contains(options[i]);
        }
    }
}
