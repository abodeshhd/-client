package hvh.client;

import com.google.gson.*;
import hvh.client.module.Module;
import hvh.client.setting.Setting;
import net.fabricmc.loader.api.FabricLoader;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;

/** صيغة الكونفك: Features -> اسم المود -> state / keyIndex / Settings (مفاتيح انجليزية). */
public class ConfigManager {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    public static final Path FILE = FabricLoader.getInstance().getConfigDir().resolve("hvhclient/hvh.cfg");

    public static void init() {
        try {
            if (!Files.exists(FILE)) {
                Files.createDirectories(FILE.getParent());
                try (InputStream in = ConfigManager.class.getResourceAsStream("/hvh.cfg")) {
                    if (in != null) Files.copy(in, FILE);
                }
            }
            load();
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void load() {
        try {
            String text = Files.readString(FILE, StandardCharsets.UTF_8);
            JsonObject root = JsonParser.parseString(text).getAsJsonObject();
            JsonObject features = root.has("Features") ? root.getAsJsonObject("Features") : new JsonObject();
            for (Module m : HvhClient.modules.modules) {
                if (!features.has(m.name)) continue;
                JsonObject o = features.getAsJsonObject(m.name);
                if (o.has("keyIndex")) m.key = o.get("keyIndex").getAsInt();
                if (o.has("Settings")) {
                    JsonObject st = o.getAsJsonObject("Settings");
                    for (Setting s : m.settings) if (st.has(s.name)) s.fromJson(st.get(s.name));
                }
                if (o.has("state")) m.setEnabled(o.get("state").getAsBoolean());
            }
        } catch (Exception e) { e.printStackTrace(); }
    }

    public static void save() {
        try {
            JsonObject root = new JsonObject();
            JsonObject features = new JsonObject();
            for (Module m : HvhClient.modules.modules) {
                JsonObject o = new JsonObject();
                o.addProperty("state", m.enabled);
                o.addProperty("keyIndex", m.key);
                JsonObject st = new JsonObject();
                for (Setting s : m.settings) st.add(s.name, s.toJson());
                o.add("Settings", st);
                features.add(m.name, o);
            }
            root.add("Features", features);
            Files.createDirectories(FILE.getParent());
            Files.writeString(FILE, GSON.toJson(root), StandardCharsets.UTF_8);
        } catch (Exception e) { e.printStackTrace(); }
    }
}
