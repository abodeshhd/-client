package hvh.client.module.impl;

import hvh.client.module.Module;

// من ABN (Aboudi_DEV, MIT)
public class Sprint extends Module {
    public Sprint() { super("Sprint", "جري تلقائي", "Movement"); }

    @Override
    public void onTick() {
        if (mc.player == null) return;
        if (mc.player.input.hasForwardMovement() && !mc.player.horizontalCollision)
            mc.player.setSprinting(true);
    }
}
