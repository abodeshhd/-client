package hvh.client.module;

import hvh.client.setting.Setting;
import net.minecraft.client.MinecraftClient;

import java.util.ArrayList;
import java.util.List;

public abstract class Module {
    protected static final MinecraftClient mc = MinecraftClient.getInstance();

    public final String name;
    public final String ar;
    public final String category;
    public final List<Setting> settings = new ArrayList<>();
    public boolean enabled;
    public int key; // GLFW key code, 0 = بدون زر
    public boolean keyDown;

    protected Module(String name, String ar, String category) {
        this.name = name;
        this.ar = ar;
        this.category = category;
    }

    protected <T extends Setting> T add(T s) { settings.add(s); return s; }

    public void toggle() { setEnabled(!enabled); }

    public void setEnabled(boolean v) {
        if (v == enabled) return;
        enabled = v;
        if (v) onEnable(); else onDisable();
    }

    public void onEnable() {}
    public void onDisable() {}
    public void onTick() {}
}
