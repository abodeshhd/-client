package hvh.client.module.impl;

import hvh.client.module.Module;
import hvh.client.setting.Setting;
import net.minecraft.item.Items;
import net.minecraft.screen.slot.SlotActionType;

public class AutoTotem extends Module {
    private final Setting.Num health = add(new Setting.Num("Health", "الصحة", 5.0, 1.0, 20.0));

    public AutoTotem() { super("AutoTotem", "توتم تلقائي", "Combat"); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.interactionManager == null) return;
        if (mc.player.getOffHandStack().isOf(Items.TOTEM_OF_UNDYING)) return;
        if (mc.player.getHealth() + mc.player.getAbsorptionAmount() > health.value) return;

        for (int i = 0; i < 36; i++) {
            if (!mc.player.getInventory().getStack(i).isOf(Items.TOTEM_OF_UNDYING)) continue;
            int slotId = i < 9 ? i + 36 : i; // الهوتبار = 36..44 بالـ screen handler
            mc.interactionManager.clickSlot(mc.player.playerScreenHandler.syncId, slotId, 40,
                    SlotActionType.SWAP, mc.player);
            return;
        }
    }
}
