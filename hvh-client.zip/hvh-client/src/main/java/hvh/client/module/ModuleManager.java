package hvh.client.module;

import hvh.client.module.impl.*;

import java.util.ArrayList;
import java.util.List;

public class ModuleManager {
    public final List<Module> modules = new ArrayList<>();

    public ModuleManager() {
        modules.add(new AttackAura());
        modules.add(new AutoTotem());
        modules.add(new Sprint());
        modules.add(new Fullbright());
        modules.add(new FpsBoost());
    }

    public Module get(String name) {
        for (Module m : modules) if (m.name.equalsIgnoreCase(name)) return m;
        return null;
    }

    public void tick() {
        for (Module m : modules) if (m.enabled) m.onTick();
    }
}
