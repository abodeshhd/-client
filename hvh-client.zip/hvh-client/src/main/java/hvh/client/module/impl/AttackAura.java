package hvh.client.module.impl;

import hvh.client.module.Module;
import hvh.client.setting.Setting;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.Hand;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

public class AttackAura extends Module {
    private final Setting.Multi targets = add(new Setting.Multi("Targets", "الأهداف",
            new String[]{"Players", "Naked", "Invisible", "Naked invisible"},
            new String[]{"لاعبين", "عراة", "غير مرئيين", "عراة غير مرئيين"},
            new boolean[]{true, true, false, false}));
    private final Setting.Mode sort = add(new Setting.Mode("Sort", "الترتيب",
            new String[]{"Distance", "Health"}, new String[]{"حسب المسافة", "حسب الصحة"}, 0));
    private final Setting.Num range = add(new Setting.Num("Range", "المدى", 3.0, 1.0, 6.0));
    private final Setting.Bool rotate = add(new Setting.Bool("Rotate", "التدوير", true));
    private final Setting.Multi opts = add(new Setting.Multi("Options", "الخيارات",
            new String[]{"Only crits", "Through walls", "Not while eating"},
            new String[]{"كريتكال فقط", "عبر الجدران", "لا تضرب أثناء الأكل"},
            new boolean[]{false, false, true}));

    public AttackAura() { super("AttackAura", "هجوم تلقائي", "Combat"); }

    @Override
    public void onTick() {
        if (mc.player == null || mc.world == null || mc.interactionManager == null) return;
        if (opts.has(2) && mc.player.isUsingItem()) return;

        PlayerEntity t = findTarget();
        if (t == null) return;
        if (rotate.value) face(t);
        if (mc.player.getAttackCooldownProgress(0.5f) < 0.93f) return;
        if (opts.has(0) && !canCrit()) return;

        mc.interactionManager.attackEntity(mc.player, t);
        mc.player.swingHand(Hand.MAIN_HAND);
    }

    private boolean canCrit() {
        return mc.player.fallDistance > 0 && !mc.player.isOnGround()
                && !mc.player.isClimbing() && !mc.player.isTouchingWater();
    }

    private PlayerEntity findTarget() {
        PlayerEntity best = null;
        double bestScore = Double.MAX_VALUE;
        for (PlayerEntity p : mc.world.getPlayers()) {
            if (p == mc.player || !p.isAlive() || p.isSpectator()) continue;
            double d = mc.player.distanceTo(p);
            if (d > range.value) continue;
            if (!allowed(p)) continue;
            if (!opts.has(1) && !mc.player.canSee(p)) continue;
            double score = sort.index == 1 ? p.getHealth() + p.getAbsorptionAmount() : d;
            if (score < bestScore) { bestScore = score; best = p; }
        }
        return best;
    }

    private boolean allowed(PlayerEntity p) {
        boolean naked = p.getEquippedStack(EquipmentSlot.HEAD).isEmpty()
                && p.getEquippedStack(EquipmentSlot.CHEST).isEmpty()
                && p.getEquippedStack(EquipmentSlot.LEGS).isEmpty()
                && p.getEquippedStack(EquipmentSlot.FEET).isEmpty();
        int idx = p.isInvisible() ? (naked ? 3 : 2) : (naked ? 1 : 0);
        return targets.has(idx);
    }

    private void face(PlayerEntity t) {
        Vec3d eye = mc.player.getEyePos();
        Vec3d to = t.getBoundingBox().getCenter();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double flat = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) (Math.toDegrees(Math.atan2(dz, dx)) - 90.0);
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, flat));
        mc.player.setYaw(MathHelper.wrapDegrees(yaw));
        mc.player.setPitch(MathHelper.clamp(pitch, -90f, 90f));
    }
}
