package hvh.client.module.impl;

import hvh.client.module.Module;

// من ABN (Aboudi_DEV, MIT)
public class FpsBoost extends Module {
    private int viewDist, simDist, biomeBlend, maxFps;
    private double entityDist;
    private boolean shadows;

    public FpsBoost() { super("FPS Boost", "رفع الفريمات", "Render"); }

    @Override
    public void onEnable() {
        var o = mc.options;
        viewDist = o.getViewDistance().getValue();
        simDist = o.getSimulationDistance().getValue();
        biomeBlend = o.getBiomeBlendRadius().getValue();
        maxFps = o.getMaxFps().getValue();
        entityDist = o.getEntityDistanceScaling().getValue();
        shadows = o.getEntityShadows().getValue();

        o.getViewDistance().setValue(6);
        o.getSimulationDistance().setValue(6);
        o.getBiomeBlendRadius().setValue(0);
        o.getEntityDistanceScaling().setValue(0.5);
        o.getEntityShadows().setValue(false);
    }

    @Override
    public void onDisable() {
        var o = mc.options;
        o.getViewDistance().setValue(viewDist);
        o.getSimulationDistance().setValue(simDist);
        o.getBiomeBlendRadius().setValue(biomeBlend);
        o.getMaxFps().setValue(maxFps);
        o.getEntityDistanceScaling().setValue(entityDist);
        o.getEntityShadows().setValue(shadows);
    }
}
