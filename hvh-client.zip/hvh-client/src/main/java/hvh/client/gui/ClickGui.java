package hvh.client.gui;

import hvh.client.ConfigManager;
import hvh.client.HvhClient;
import hvh.client.module.Module;
import hvh.client.setting.Setting;
import net.minecraft.client.gui.Click;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.input.KeyInput;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.*;

/**
 * كليك يسار = تشغيل/إيقاف | كليك يمين = فتح الإعدادات | كليك وسط = تغيير الزر (Esc = حذف الزر)
 */
public class ClickGui extends Screen {
    private static final String[] CATS = {"Combat", "Movement", "Render"};
    private static final String[] CATS_AR = {"قتال", "حركة", "عرض"};
    private static final Set<Module> expanded = new HashSet<>();
    private static final int W = 175, H = 15, SH = 13;

    private record Row(int x, int y, int w, int h, Module m, Setting s, int opt) {
        boolean hit(double mx, double my) { return mx >= x && mx < x + w && my >= y && my < y + h; }
    }

    private final List<Row> rows = new ArrayList<>();
    private Row dragging;
    private Module listening;

    public ClickGui() { super(Text.literal("ClickGUI")); }

    @Override public boolean shouldPause() { return false; }
    @Override public void removed() { ConfigManager.save(); }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        ctx.fill(0, 0, width, height, 0x66000000);
        rows.clear();
        int px = 12;
        for (int ci = 0; ci < CATS.length; ci++) {
            String cat = CATS[ci];
            int y = 12;
            ctx.fill(px, y, px + W, y + H, 0xFF1B1B2B);
            ctx.drawText(textRenderer, cat, px + 5, y + 4, 0xFFFFFFFF, true);
            right(ctx, CATS_AR[ci], px + W - 5, y + 4, 0xFFFFFFFF);
            y += H;
            for (Module m : HvhClient.modules.modules) {
                if (!m.category.equals(cat)) continue;
                y = addRow(ctx, new Row(px, y, W, H, m, null, -1));
                if (!expanded.contains(m)) continue;
                for (Setting s : m.settings) {
                    if (s instanceof Setting.Multi mu) {
                        for (int i = 0; i < mu.options.length; i++) y = addRow(ctx, new Row(px, y, W, SH, m, s, i));
                    } else y = addRow(ctx, new Row(px, y, W, SH, m, s, -1));
                }
            }
            px += W + 6;
        }
    }

    private void right(DrawContext ctx, String text, int xRight, int y, int color) {
        ctx.drawText(textRenderer, text, xRight - textRenderer.getWidth(text), y, color, true);
    }

    private int addRow(DrawContext ctx, Row r) {
        rows.add(r);
        if (r.s == null) {
            ctx.fill(r.x, r.y, r.x + r.w, r.y + r.h, r.m.enabled ? 0xFF3A6EA5 : 0xE0141420);
            String left = r.m.name;
            if (listening == r.m) left += " <key>";
            else if (r.m.key > 0) {
                String k = GLFW.glfwGetKeyName(r.m.key, 0);
                left += " [" + (k == null ? "#" + r.m.key : k.toUpperCase()) + "]";
            }
            ctx.drawText(textRenderer, left, r.x + 5, r.y + 4, 0xFFFFFFFF, true);
            right(ctx, r.m.ar, r.x + r.w - 5, r.y + 4, 0xFFDDDDDD);
        } else {
            ctx.fill(r.x, r.y, r.x + r.w, r.y + r.h, 0xE00C0C16);
            String left, rightText;
            if (r.s instanceof Setting.Num n) {
                int fw = (int) (r.w * (n.value - n.min) / (n.max - n.min));
                ctx.fill(r.x, r.y, r.x + fw, r.y + r.h, 0xFF2D5580);
                left = n.name + ": " + n.value;
                rightText = n.ar;
            } else if (r.s instanceof Setting.Bool b) {
                left = b.name + ": " + (b.value ? "ON" : "OFF");
                rightText = b.ar;
            } else if (r.s instanceof Setting.Mode md) {
                left = md.name + ": " + md.get();
                rightText = md.getAr();
            } else {
                Setting.Multi mu = (Setting.Multi) r.s;
                left = (mu.on[r.opt] ? "[x] " : "[ ] ") + mu.options[r.opt];
                rightText = mu.optionsAr[r.opt];
            }
            ctx.drawText(textRenderer, left, r.x + 9, r.y + 3, 0xFFDDDDDD, true);
            right(ctx, rightText, r.x + r.w - 5, r.y + 3, 0xFFAAAAAA);
        }
        return r.y + r.h;
    }

    private void setNum(Row r, double mx) {
        Setting.Num n = (Setting.Num) r.s;
        n.set(n.min + Math.max(0, Math.min(1, (mx - r.x) / r.w)) * (n.max - n.min));
    }

    @Override
    public boolean mouseClicked(Click click, boolean doubled) {
        double mx = click.x(), my = click.y();
        int b = click.button();
        for (Row r : rows) {
            if (!r.hit(mx, my)) continue;
            if (r.s == null) {
                if (b == 0) r.m.toggle();
                else if (b == 1) { if (!expanded.remove(r.m)) expanded.add(r.m); }
                else if (b == 2) listening = r.m;
            } else if (r.s instanceof Setting.Bool bo) bo.value = !bo.value;
            else if (r.s instanceof Setting.Mode md) md.cycle();
            else if (r.s instanceof Setting.Multi mu) mu.on[r.opt] = !mu.on[r.opt];
            else if (r.s instanceof Setting.Num) { dragging = r; setNum(r, mx); }
            return true;
        }
        return super.mouseClicked(click, doubled);
    }

    @Override
    public boolean mouseDragged(Click click, double dx, double dy) {
        if (dragging != null) { setNum(dragging, click.x()); return true; }
        return super.mouseDragged(click, dx, dy);
    }

    @Override
    public boolean mouseReleased(Click click) {
        dragging = null;
        return super.mouseReleased(click);
    }

    @Override
    public boolean keyPressed(KeyInput input) {
        int key = input.key();
        if (listening != null) {
            listening.key = key == GLFW.GLFW_KEY_ESCAPE ? 0 : key;
            listening = null;
            return true;
        }
        if (key == HvhClient.GUI_KEY) { close(); return true; }
        return super.keyPressed(input);
    }
}
